/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import Portfolio from './components/Portfolio';

export default function App() {
  return <Portfolio />;
}
